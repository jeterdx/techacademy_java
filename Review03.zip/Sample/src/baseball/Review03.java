package baseball;

public class Review03 {

    public static void main(String[] args) {
        BaseBallTeam giants = new BaseBallTeam();
        BaseBallTeam tigers = new BaseBallTeam();
        BaseBallTeam dragons = new BaseBallTeam();
        BaseBallTeam baystars = new BaseBallTeam();
        BaseBallTeam swallows = new BaseBallTeam();
        BaseBallTeam carp = new BaseBallTeam();

        giants.setName("東京読売ジャイアンツ");
        giants.setWin(67);
        giants.setLose(45);
        giants.setDraw(8);
        giants.report();

        tigers.setName("阪神タイガース");
        tigers.setWin(60);
        tigers.setLose(53);
        tigers.setDraw(7);
        tigers.report();

        dragons.setName("中日ドラゴンズ");
        dragons.setWin(60);
        dragons.setLose(55);
        dragons.setDraw(5);
        dragons.report();

        baystars.setName("横浜DeNAベイスターズ");
        baystars.setWin(56);
        baystars.setLose(58);
        baystars.setDraw(6);
        baystars.report();

        carp.setName("広島東洋カープ");
        carp.setWin(52);
        carp.setLose(56);
        carp.setDraw(12);
        carp.report();

        swallows.setName("東京ヤクルトスワローズ");
        swallows.setWin(41);
        swallows.setLose(69);
        swallows.setDraw(10);
        swallows.report();

    }

}
