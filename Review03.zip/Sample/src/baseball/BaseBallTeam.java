package baseball;

public class BaseBallTeam {
    //Define fields
    private String name;
    private int win;
    private int lose;
    private int draw;

    //Define getter and setter for private variables
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public int getWin() {
        return win;
    }
    public void setWin(int win) {
        this.win = win;
    }

    public int getLose() {
        return lose;
    }
    public void setLose(int lose) {
        this.lose = lose;
    }

    public int getDraw() {
        return draw;
    }
    public void setDraw(int draw) {
        this.draw = draw;
    }

    //Define getRate method
    public double getRate() {
        double dWin = win; //Implicit change of data type happens if int type is used to formula, so explicit change data type is needed.
        double dLose = lose;
;        return dWin/(dWin+dLose);
    }

    //Define report method
    public void report() {
        System.out.println(getName() +" の2020年の成績は "+ getWin() + "勝 " + getLose() + "敗 " + getDraw() + "分、勝率は " + getRate() + " です。");
    }
}