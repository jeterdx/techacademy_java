package animal;

public class Animal {

    //カプセル化されたフィールド情報を設定
    private String name;
    private int age;

    //GetterとSetterを定義
    public String getName () {
        return this.name;
    }
    public void setName (String name) {
        this.name = name;
    }

    public int getAge () {
        return this.age;
    }
    public void setAge (int age) {
        this.age = age;
    }

    //コンストラクタを定義
    public Animal() {
        //何もないパターン
    }
    public Animal (String name, int age) {
        this.name = name;
        this.age = age;
    }

    public void say() {
        System.out.println(this.name + " です。" + this.age + "歳です。");

    }

}
