package animal;

public class Human extends Animal implements Thinkable {

    @Override
    public void think() {
        System.out.println("私は" + this.getHobby() + "について考えます。");
    }

    //Private変数でカプセル化＆Setter/Getterをセット
    private String hobby;
    public String getHobby () {
        return this.hobby;
    }
    public void setHobby (String hobby) {
        this.hobby = hobby;
    }

    public Human (String name, int age, String hobby) {
        super.setName(name);
        super.setAge(age);
        this.hobby = hobby;

    }


}
