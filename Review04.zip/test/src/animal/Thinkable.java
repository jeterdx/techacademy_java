package animal;

public interface Thinkable {
    public abstract void think();
}
